Sample Application using Vertical Slice Architecture.

Following packages are used

- Softaware CQS https://github.com/softawaregmbh/library-cqs
- EF Core
- Scalar for OpenAPI Doc
