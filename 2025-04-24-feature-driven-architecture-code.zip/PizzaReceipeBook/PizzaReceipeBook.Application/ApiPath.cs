namespace PizzaReceipeBook.Application;

public static class ApiPath
{
    public const string Base = "api"; 
}