using System.Diagnostics;
using softaware.Cqs;

namespace PizzaReceipeBook.Host.Decorator;

public class CommandTimeSpentDecorator<TRequest, TResult>(IRequestHandler<TRequest, TResult> handler) : IRequestHandler<TRequest, TResult> where TRequest : ICommand<TResult>
{
    public async Task<TResult> HandleAsync(TRequest request, CancellationToken cancellationToken)
    {
        var sw = new Stopwatch();
        sw.Start();
        
        var result = await handler.HandleAsync(request, cancellationToken);
        
        sw.Stop();
        Console.WriteLine($"{sw.ElapsedMilliseconds} ms");

        return result;
    }
}